let listsContainer = document.getElementById('lists-container');
let taskModal = document.getElementById('task-modal');
let modalTitle = document.getElementById('modal-title');
let taskText = document.getElementById('task-text');
let taskDateTime = document.getElementById('task-datetime');
let saveTaskBtn = document.getElementById('save-task-btn');
let currentList = null;
let currentTask = null;

// Add new list
document.getElementById('add-list-btn').addEventListener('click', function() {
    let listName = document.getElementById('new-list').value.trim();

    if (listName) {
        let list = document.createElement('div');
        list.classList.add('list');

        let listHeader = document.createElement('h3');
        listHeader.textContent = listName;

        let addTaskBtn = document.createElement('button');
        addTaskBtn.textContent = 'Add Task';
        addTaskBtn.addEventListener('click', function() {
            openTaskModal('Add Task', list);
        });

        listHeader.appendChild(addTaskBtn);
        list.appendChild(listHeader);

        let taskList = document.createElement('ul');
        list.appendChild(taskList);

        listsContainer.appendChild(list);
        document.getElementById('new-list').value = '';
    }
});

// Open task modal
function openTaskModal(title, list, task = null) {
    modalTitle.textContent = title;
    taskText.value = task ? task.textContent : '';
    taskDateTime.value = task ? task.getAttribute('data-datetime') : '';
    currentList = list;
    currentTask = task;
    taskModal.style.display = 'block';
}

// Save task
saveTaskBtn.addEventListener('click', function() {
    let taskName = taskText.value.trim();
    let dateTime = taskDateTime.value;

    if (taskName && currentList) {
        if (currentTask) {
            currentTask.textContent = `${taskName} (${dateTime})`;
            currentTask.setAttribute('data-datetime', dateTime);
        } else {
            let li = document.createElement('li');
            li.classList.add('task');
            li.textContent = `${taskName} (${dateTime})`;
            li.setAttribute('data-datetime', dateTime);

            let editBtn = document.createElement('button');
            editBtn.textContent = 'Edit';
            editBtn.classList.add('edit-btn');
            editBtn.addEventListener('click', function() {
                openTaskModal('Edit Task', currentList, li);
            });

            let deleteBtn = document.createElement('button');
            deleteBtn.textContent = 'Delete';
            deleteBtn.classList.add('delete-btn');
            deleteBtn.addEventListener('click', function() {
                li.remove();
            });

            li.appendChild(editBtn);
            li.appendChild(deleteBtn);

            li.addEventListener('click', function() {
                li.classList.toggle('completed');
            });

            currentList.querySelector('ul').appendChild(li);
        }

        taskModal.style.display = 'none';
    }
});

// Close task modal
document.querySelector('.close').addEventListener('click', function() {
    taskModal.style.display = 'none';
});

// Close modal on outside click
window.addEventListener('click', function(event) {
    if (event.target == taskModal) {
        taskModal.style.display = 'none';
    }
});
